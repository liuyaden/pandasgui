from typing import Dict, Any

Data = Dict[str, Any]
